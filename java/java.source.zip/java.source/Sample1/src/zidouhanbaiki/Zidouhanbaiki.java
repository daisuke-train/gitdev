package zidouhanbaiki;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Zidouhanbaiki {

	public static void main(String[] args) {

		System.out.println("お金を入れてください");
		int okane = 0;

		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			okane = Integer.parseInt(br.readLine());
			if(okane % 10 != 0){
				System.out.println("5円硬貨か1円硬貨が混じっています");
				System.out.println("お釣りを返します");
				System.out.println("おつりは " + okane + "円です");
				return;
			}
			if(okane < 100){
				System.out.println("商品を買えません");
				System.out.println("お釣りを返します");
				System.out.println("おつりは " + okane + "円です");

			}

		}

		// 金額に文字列を入力した時の処理内容
		catch(NumberFormatException e){
			Message message = new Message();
			message.Input_String();
			return;

		}
		catch(IOException e){
			Message message = new Message();
			message.IOException_error();
			return;
		}
		if(okane <= 0 || okane > 1000){
			Message message = new Message();
			message.value_over();
			return;
		}else{
			System.out.println("入力された金額は" + okane + "円です");
		}

		Message message = new Message();
		message.item_list();

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				int oturi = 0;
				String select_item = br.readLine();
				if(select_item.equals("コーラ")){

					if(oturi <= 120){
						System.out.println("お金が足りません");
						System.out.println("おつりは " + oturi + "円です");
					}else{
						oturi =	okane - 120;
						System.out.println("コーラを買いました。");
						System.out.println("おつりは " + oturi + "円です");
					}
				}else if (select_item.equals("お茶")){
					if(oturi <= 100){
						System.out.println("お金が足りません");
						System.out.println("おつりは " + oturi + "円です");
					}else{
						oturi =	okane - 100;
						System.out.println("お茶を買いました。");
						System.out.println("おつりは " + oturi + "円です");
					}
				}else{
					System.out.println("商品以外のアイテムが選択されました。");
					}
				}
		catch(IOException e){
				message.IOException_error();
			}
		finally{
			System.out.println("処理が完了しました");
		}
	}

}
