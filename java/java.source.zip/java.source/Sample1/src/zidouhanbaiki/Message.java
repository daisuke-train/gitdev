package zidouhanbaiki;


public class Message {

	void Input_String(){
		System.out.println("文字列を入力しました。");
		System.out.println("金額を入力してください");
	}

	void IOException_error(){
		System.out.println("入力もしくは出力にエラーがあります。");
	}

	void value_over(){
		System.out.println("入力できる金額の上限もしくは下限を超えています。");

	}

	void item_list(){
		System.out.println("購入する商品を選んでください。");
		System.out.println("コーラ 120円  お茶100円");
	}

}
