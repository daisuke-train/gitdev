package addNumber;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class addNumber {

	public int addNumber(){

		int[] inputNum = new int[2];

		for(int i = 0; i <= 1; i++){

			try {
				BufferedReader br = new BufferedReader(new
						InputStreamReader(System.in));

				System.out.println(i + "番目の値を入力してください");

				String str = br.readLine();

				try{
					int num = Integer.parseInt(str)	;
						inputNum[i] = num;

				}catch(NumberFormatException e) {
					System.out.println("入力された文字列が変換できませんでした");
					break;

				}

			} catch (IOException e) {
				System.out.println("キーボード入力でエラーが発生しました");
			}
		}

		int add_Num = inputNum[0] + inputNum[1];
		return add_Num;
 	}

}
