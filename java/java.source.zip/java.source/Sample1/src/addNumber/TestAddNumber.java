package addNumber;

public class TestAddNumber {

	public static void main(String[] args) {
		addNumber addNumber = new addNumber();
		int total_Number = addNumber.addNumber();
			System.out.println("入力された値の合計は"+ total_Number + "です");

	}

}
