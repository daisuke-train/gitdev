package prime_Number;

public class Counter {

	void prime_number_check(){
		int number,i;

		for(number = 1; number <= 100; number++){
			int counter = 0;

			for(i = 1; i <= number ; i++){
				if(number % i == 0){
					counter++;
				}
			}

			if(counter == 2){
				System.out.println(number);
			}

		}
	}

}

