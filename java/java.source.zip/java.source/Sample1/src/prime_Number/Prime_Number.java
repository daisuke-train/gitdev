package prime_Number;

public class Prime_Number {

	public static void main(String[] args) {

		Counter counter = new Counter();
		counter.prime_number_check();
	}
}


