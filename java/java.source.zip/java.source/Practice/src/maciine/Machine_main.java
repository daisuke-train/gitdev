package maciine;

public class Machine_main {

	public static void main(String[] args) {

		Machine machine1 = new Machine();

		boolean r1 = machine1.mix("砂糖", "水", "香料");

		if(r1){
			boolean r2 = machine1.molding(100, "丸");
		}if(r2){
			System.out.println("アメの成形が完了しました");
		}else{
			System.out.println("アメの成形に失敗しました");
		}


		//machine1.serialNumber = "M001";
		//machine1.setSerialNumber("M001");
		//machine1.height = 100;
		//machine1.width = 120;
		//machine1.weight = 80;
		//machine1.product = "キャンディ（レモン味)";
		//machine1.capacity = 100;

		// System.out.println("machine1の型番は" + machine1.serialNumber + "です。");
		// System.out.println("machine1の高さは" + machine1.height + "です。");
		// System.out.println("machine1の幅は" + machine1.width + "です。");
		// System.out.println("machine1の重さは" + machine1.weight + "です。");
		// System.out.println("machine1の生産物は" + machine1.product + "です。");
		// System.out.println("machine1の生産能力は" + machine1.capacity + "です。");

		//Machine machine2 = new Machine();

		//machine2.serialNumber = "M002";
		//machine2.setSerialNumber("M002");
		//machine2.height = 150;
		//machine2.width = 130;
		//machine2.weight = 100;
		//machine2.product = "キャンディ（メロン味)";
		//machine2.capacity = 80;


		// System.out.println("machine2の型番は" + machine2.serialNumber + "です。");
		// System.out.println("machine2の高さは" + machine2.height + "です。");
		// System.out.println("machine2の幅は" + machine2.width + "です。");
		// System.out.println("machine2の重さは" + machine2.weight + "です。");
		// System.out.println("machine2の生産物は" + machine2.product + "です。");
		// System.out.println("machine2の生産能力は" + machine2.capacity + "です。");

		//machine1.showData();
		//machine2.showData();

	}

}
