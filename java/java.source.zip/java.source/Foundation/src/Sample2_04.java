
public class Sample2_04 {

	public static void main(String[] args) {
		System.out.println("はじめまして + Java + です。");
		System.out.println("1990年代にサン・マイクロシステムズによって開発されました。");
		System.out.println("javaは_Oで開発することができます。" );

	}

}
