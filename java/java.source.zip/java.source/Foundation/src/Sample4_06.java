
public class Sample4_06 {

	public static void main(String[] args) {

		int inumber = 30;
		double dnumber;

		System.out.println("1フィートは約" + inumber + "センチメートルです。");

		dnumber = inumber;
		System.out.println("1フィートは約" + dnumber + "センチメートルです。");

	}

}
