package jp.winschool.java.chapter5;

public class Sample5_04 {

	public static void main(String[] args) {
		
		int weather = (int)Math.floor(Math.random() * 10);
		
		switch(weather){
			case 1:
				System.out.println("穂乃果");
				System.out.println("ファイトだよ!");
				break;
			case 2:
				System.out.println("絵里");
				System.out.println("ハラショー");
				break;
			case 3:
				System.out.println("海未");
				System.out.println("ラブアローシュート!!");
				break;
			case 4:
				System.out.println("ことり");
				System.out.println("ナンデモナイノヨ ナンデモ");
				break;
			case 5:
				System.out.println("凛");
				System.out.println("ニャンニャンニャーン！");
				break;
			case 6:
				System.out.println("真姫");
				System.out.println("ｲﾐﾜｶﾝﾅｲ");
				break;
			case 7:
				System.out.println("希");
				System.out.println("スピリチュアルやね！");
				break;
			case 8:
				System.out.println("花陽");
				System.out.println("ﾀﾞﾚｶﾀｽｹﾃｰ");
				break;
			case 9:
				System.out.println("にこ");
				System.out.println("にこにっこにー");
				break;
			default:
				System.out.println("返事がない。ただのインクリングのようだ。");
				
		
		}
		
	
	}

}
