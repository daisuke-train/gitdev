package jp.winschool.java.chapter3;

public class Sample3_02 {

	public static void main(String[] args) {
		boolean b = true;
		char c =120;
		byte by = 40;
		short s = 5926;
		int i = 4999999;
		long l = 9223372036854775807l;
		float f = 10.1f;
		double d = 100.254;
		
		System.out.println(b);
		System.out.println(c);
		System.out.println(by);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
		

	}

}
