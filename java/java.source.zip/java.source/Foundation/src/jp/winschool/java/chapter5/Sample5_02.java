package jp.winschool.java.chapter5;

public class Sample5_02 {

	public static void main(String[] args) {

		int a = (int)Math.floor(Math.random() * 10);
		
		System.out.println("aの値は" + a + "です。");

		if(a >= 5){
			System.out.println("5以上です。");
		}else{
			System.out.println("5未満です。");

		}

	}

}
