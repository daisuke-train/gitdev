package jp.winschool.java.chapter4;

public class Sample4_01 {

	public static void main(String[] args) {

		int number1 = 23;
		int number2 = 10;

		System.out.println("算術演算子の練習です。");
		System.out.println(number1 + "+" + number2 + "="  + (number1 + number2));
		System.out.println(number1 + "-" + number2 + "="  + (number1 - number2));
		System.out.println(number1 + "*" + number2 + "="  + (number1 * number2));
		System.out.println(number1 + "+" + number2 + "="  + (number1 / number2));
		System.out.println(number1 + "+" + number2 + "="  + (number1 % number2));

	}

}
