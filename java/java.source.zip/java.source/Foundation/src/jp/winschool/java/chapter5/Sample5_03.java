package jp.winschool.java.chapter5;

public class Sample5_03 {

	public static void main(String[] args) {

		int a,b = 0;
		a = (int)Math.floor(Math.random() * 10);
		b = (int)Math.floor(Math.random() * 10);

		System.out.println("aの値は" + a + "です。");
		System.out.println("bの値は" + b + "です。");

		if(a >= b){
			System.out.println("aはbより大きい値です。");
		}else if(a == b){
			System.out.println("aはbと同じ値です。");
		}else{
		System.out.println("aはbより小さい値です。");
		}


	}

}
