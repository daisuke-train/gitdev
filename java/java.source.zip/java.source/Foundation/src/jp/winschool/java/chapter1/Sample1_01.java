package jp.winschool.java.chapter1;

public class Sample1_01 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
        System.out.println("Hello world");
	}

}
