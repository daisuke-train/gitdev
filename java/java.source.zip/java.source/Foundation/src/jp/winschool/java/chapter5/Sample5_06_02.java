package jp.winschool.java.chapter5;

public class Sample5_06_02 {

	public static void main(String[] args) {
		int area = (int)Math.floor(Math.random() * 10);

		switch（area）{
		case 10:
			System.out.println("穂乃果");
			System.out.println("ファイトだよ!");
			break;
		case 2:
			System.out.println("絵里");
			System.out.println("ハラショー");
			break;
		case 3:
			System.out.println("海未");
			System.out.println("ラブアローシュート!!");
			break;
		case 4:
			System.out.println("ことり");
			System.out.println("ナンデモナイノヨ ナンデモ");
			break;
		case 5:
		System.out.println("凛");
		System.out.println("ニャンニャンニャーン！");
		break;
	default:

	}

}
