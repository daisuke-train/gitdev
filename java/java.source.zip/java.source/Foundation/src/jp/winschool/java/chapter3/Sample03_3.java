package jp.winschool.java.chapter3;

public class Sample03_3 {

	public static void main(String[] args) {
		int a;

		a = 10;
		System.out.println(a);

		a = 120;
		System.out.println(a);
	}

}
