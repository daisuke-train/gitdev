package jp.winschool.java.chapter3;

public class Sample03_4 {

	public static void main(String[] args) {
		int a;
		int b;

		a  = 10;
		b  = 20;

		System.out.println("a =" + a);
		System.out.println("b =" + b);

		a = b;
		System.out.println("bの値をaに渡した");
		System.out.println("a =" + a);
		System.out.println("b =" + b);

	}

}
