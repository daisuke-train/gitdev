package jp.winschool.java.chapter5;

public class Sample5_06_01 {

	public static void main(String[] args) {
		int area = (int)(Math.floor(Math.random() *10));

		System.out.println("あなたの指定した広さは"+ area + "畳です。");
		
		if(area >= 10){
			System.out.println("家賃が60000円以上になります。");
		}else if(area == 9){
			System.out.println("家賃が55000円以上になります。");
		}else if(area == 8){
			System.out.println("家賃が50000円以上になります。");
		}else if(area == 7){
			System.out.println("家賃が45000円以上になります。");
		}else if(area == 6){
			System.out.println("家賃が40000円以上になります。");
		}else{
			System.out.println("一度ご相談ください。");
		
		}
		
	}

}
