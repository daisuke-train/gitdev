package jp.winschool.java.chapter3;

public class Sample3_01 {

	public static void main(String[] args) {
		short i;
		i =130;
		System.out.println(i);

	}

}
