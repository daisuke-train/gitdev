package jp.winschool.java.chapter4;

public class Sample4_02 {

	public static void main(String arg[]){
		int a = 0;
		int b = 0;
		int c;

		c = ++a;
		System.out.println("前置インクリメントの結果ｃは"+ c + " に、aは、" + a + "になりました。") ;

		c = b++;
		System.out.println("後置インクリメントの結果ｃは"+ c + " に、bは、" + b + "になりました。") ;
	}
}
