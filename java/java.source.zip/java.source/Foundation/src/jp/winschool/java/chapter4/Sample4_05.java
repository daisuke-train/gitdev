package jp.winschool.java.chapter4;

public class Sample4_05 {

	public static void main(String arg[]){

		int a = 5;
		int b = 4;

		System.out.println(a + "+" + b + "=" + (a + b));
		System.out.println(a + "*" + b + "=" + a * b);
	}

}
