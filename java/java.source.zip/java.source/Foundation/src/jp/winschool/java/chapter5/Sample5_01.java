package jp.winschool.java.chapter5;

public class Sample5_01 {

	public static void main(String[] args) {

		int a = 3;
		int b = 10;


		System.out.println(a == b);
		System.out.println(a != b);
		System.out.println(a > b);
		System.out.println(a >= b);
		System.out.println(a < b);
		System.out.println(a <= b);

	}

}
