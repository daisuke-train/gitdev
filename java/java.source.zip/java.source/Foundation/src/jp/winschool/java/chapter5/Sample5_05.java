package jp.winschool.java.chapter5;

public class Sample5_05 {

	public static void main(String[] args) {

		int yachin = 60000;
		int area = 11;

		if( yachin < 60000 && area < 10){
			System.out.println("手頃ないい物件が見つかりそうです。");
		}else if(yachin >= 60000 && area < 10){
			System.out.println("その家賃ならもう少し広い部屋がありますよ。");
		}else if(yachin < 60000 && area >= 10){
			System.out.println("ここまでなかなかいい物件はありませんよ");
		}else if(yachin >= 60000 && area >= 10){
			System.out.println("高級感のあるいい物件がありますよ。");


		}

	}

}
