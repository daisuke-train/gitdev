package jp.winschool.java.chapter2;

public class Sample2_02 {

	public static void main(String[] args) {
		System.out.println("はじめまして、\nJavaです。");
		System.out.println("はじめまして、\tJavaです。");
		System.out.println("はじめまして、\\Javaです。");
		System.out.println("はじめまして、\'Java\'です。");
		System.out.println("はじめまして、\"Java\"です。");

	}

}
