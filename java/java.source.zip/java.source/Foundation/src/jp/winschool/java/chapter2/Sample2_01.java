package jp.winschool.java.chapter2;

public class Sample2_01 {

	public static void main(String arg[]){
		System.out.println("明日は");
		System.out.println("曇りに");
		System.out.println("なりそうです。");
	}






}
