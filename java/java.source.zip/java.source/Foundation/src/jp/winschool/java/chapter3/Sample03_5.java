package jp.winschool.java.chapter3;

public class Sample03_5 {

	public static void main(String[] args) {
			int a,b,c;
			a = 10;
			b = 20;
			// c にaとbをかけたものを代入する
			c = a * b;
			
			System.out.println("cの値は"+ c + "です。");

	}

}
