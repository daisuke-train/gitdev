
public class Sample4_11 {

	public static void main(String[] args) {
		System.out.println(0.5 * 5.1);
		System.out.println((int)0.5 * (int)5.1);
		System.out.println(0.1 * 0.1);
		System.out.println(0.01 * 0.001);

	}

}
