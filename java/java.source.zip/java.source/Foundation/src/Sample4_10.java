
public class Sample4_10 {

	public static void main(String[] args) {
		int a,b,c,d;

		a = (5+4) * 20;
		b = (5+4) * 20 + 10 * 200;
		c = ((5+4) * 20 + 10 * 200) * (500 * 100 + 200 / 10);
		d = ((5+4) * 20 + 10 * 200) * (500 * 100 + 200 / 10) * 100;

		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}

}
