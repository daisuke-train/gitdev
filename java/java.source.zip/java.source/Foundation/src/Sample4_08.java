
public class Sample4_08 {

	public static void main(String[] args) {
		int inumber = 5;
		double dnumber = 30.48;

		System.out.println(inumber + "フィートは約" + (inumber * dnumber) + "センチメートルです。");

	}

}
