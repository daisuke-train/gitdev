
public class Sample4_09 {

	public static void main(String[] args) {
	int number1 = 10;
	int number2 = 4;
	double div = (double)number1  / (double)number2;

	System.out.println(number1 + "メートルの" + number2 + "分の１は" +
	                                  div + "メートルです。");

	}

}
